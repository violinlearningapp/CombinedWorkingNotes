﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClickSound : MonoBehaviour {

    void Awake()
    {
        GameObject[] objs = GameObject.FindGameObjectsWithTag("Click");
        if (objs.Length > 1)
            Destroy(objs[0]);
        DontDestroyOnLoad(this.gameObject);

        //DEBUGGING
        //for (int i = 0; i < objs.length; i++)
        //{
        //    debug.log(i);
        //}

    }
}
