﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TuneBallColor : MonoBehaviour
{

    public GameObject gRed;
    public GameObject dRed;
    public GameObject aRed;
    public GameObject eRed;

    public Text test;

    float freq = tuner.aimFrequency;


    public void Update()
    {
        
        gRed = GameObject.FindWithTag("GBall");
        dRed = GameObject.FindWithTag("DBall");
        aRed = GameObject.FindWithTag("ABall");
        eRed = GameObject.FindWithTag("EBall");



       



        if (freq != 440f)
        {
            aRed.GetComponent<Renderer>().enabled = true;
        }
        
        if (freq == 440f)
        {
            gRed.GetComponent<Renderer>().enabled = false;
        }
        


    }

}
