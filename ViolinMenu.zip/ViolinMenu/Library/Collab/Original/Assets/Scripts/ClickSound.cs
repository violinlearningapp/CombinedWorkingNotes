﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClickSound : MonoBehaviour {


    void Awake()
    {
       
        GameObject[] objs = GameObject.FindGameObjectsWithTag("Click");

        for (int i = 0; i < objs.Length; i++)
        {
            if (objs.Length > 1)
            Destroy(objs[i]);
        }
        


        for (int i = 0; i < objs.Length; i++)
        {
            Debug.Log(objs.Length);
        }
       
        DontDestroyOnLoad(this.gameObject);
    }
}
